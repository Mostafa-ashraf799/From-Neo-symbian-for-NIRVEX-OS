# NRX-1 — the kernel of NIRVEX OS

NRX-1 is a fork of Symbian's EKA2 kernel (EPL-1.0, from SymbianSource `kernelhwsrv`, upstream commit `0c3208650587ac0230aed8a74e9bddb5288023eb`), being modernised for ARM only.
`kernelhwsrv/` is the **unmodified upstream source** (we patch only at build time, never in place). Everything NIRVEX-specific lives outside it.

## Layout
| path | what |
|---|---|
| `kernelhwsrv/` | upstream EKA2 (nanokernel, kernel, memory models, drivers…) |
| `bsp/versatilepb`, `bsp/vexpress-a9`, `bsp/virt-a15` | board support: vectors, IRQ stub, timer, interrupt controller, UART, bring-up threads |
| `nrx-micro/` | **NRX-1 Micro**: new small preemptive kernel for Cortex-M (Ultra-lite edition) |
| `tools/symbian_exports.py` | rebuilds the `epoc32/include` export tree from the `bld.inf` files (no Symbian toolchain needed) |
| `build/` | scripts that build the real nanokernel with arm-none-eabi-gcc |
| `dist/` | prebuilt images (run on QEMU) |
| `docs/` | NIRVEX OS vision/plan, CPU-support plan, bring-up log |

## Build and run (needs gcc-arm-none-eabi, qemu-system-arm, python3)
```
bash build/build.sh versatilepb    # ARM926EJ-S  (ARMv5)       QEMU versatilepb
bash build/build.sh vexpress-a9    # Cortex-A9   (ARMv7-A)     QEMU vexpress-a9
bash build/build.sh virt-a15       # Cortex-A15  (ARMv7-A)     QEMU virt, GICv2 + generic timer
bash nrx-micro/build.sh m3         # Cortex-M3   (ARMv7-M)     QEMU mps2-an385
bash nrx-micro/build.sh m33        # Cortex-M33  (ARMv8-M)     QEMU mps2-an505
```
Each prints `SUCCESS` once real context switches are seen.

## Status (honest)
Working: MMU+caches on (Cortex-A9, flat map + alias test); real EKA2 nanokernel (threads, priorities, timeslicing, NKern::Sleep, timer queue, DFC thread, IRQ path) on ARMv5 and ARMv7-A, uniprocessor, plus the Cortex-M micro-kernel.
Not done yet: memory models/MMU/user mode, the full kernel layer (K::Init…), file server, drivers, SMP bring-up (nkernsmp builds+links; needs own bootstrap: VIB, IRQ preambles, AP boot — see docs/BRINGUP-LOG.md Phase 3), AArch64/ARMv8-A/ARMv9, Touch/Desktop/Server editions, ~150 of the .cia files are untested.
Build-time patches: `build/try_cia.sh` patches a copy of `ncsched.cia` (missing ';'). Clean-rebuild when switching CPU.
